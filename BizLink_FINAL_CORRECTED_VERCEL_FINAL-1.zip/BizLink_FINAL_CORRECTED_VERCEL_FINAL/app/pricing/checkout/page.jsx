 "use client";
import {useState} from "react";

export default function Checkout(){
 const [message,setMessage]=useState("");
 async function pay(){
   setMessage("");
   const res=await fetch("/api/payments/initialize",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({plan:"featured_monthly"})});
   const data=await res.json();
   if(!res.ok){setMessage(data.error||"Payment initialization failed.");return;}
   if(data.authorization_url) window.location.href=data.authorization_url;
   else setMessage("Payment provider response received.");
 }
 return <div className="container"><h1>Featured plan</h1><div className="card"><p>Monthly featured placement.</p><button className="btn" onClick={pay}>Continue to payment</button>{message&&<div className="notice">{message}</div>}</div></div>
}
