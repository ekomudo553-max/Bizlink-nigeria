import { createSupabaseServerClient } from "../../../../lib/supabase/server";

export async function POST(request) {
  try {
    const supabase = await createSupabaseServerClient();

    const {
      data: { user },
      error: authError
    } = await supabase.auth.getUser();

    if (authError || !user) {
      return new Response("Unauthorized", { status: 401 });
    }

    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profileError || profile?.role !== "admin") {
      return new Response("Forbidden", { status: 403 });
    }

    const form = await request.formData();
    const id = form.get("id");
    const status = form.get("status");

    if (!id || !["pending", "approved", "rejected"].includes(status)) {
      return new Response("Invalid request", { status: 400 });
    }

    const { error } = await supabase
      .from("businesses")
      .update({ status })
      .eq("id", id);

    if (error) {
      return new Response(error.message, { status: 400 });
    }

    return Response.redirect(new URL("/admin", request.url), 303);
  } catch (error) {
    return new Response(error.message || "Server error", { status: 500 });
  }
}
