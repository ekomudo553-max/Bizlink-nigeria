import {createSupabaseServerClient} from "../../../lib/supabase/server";

export async function POST(request){
  try{
    const supabase=await createSupabaseServerClient();
    const {data:{user}}=await supabase.auth.getUser();
    if(!user)return Response.json({error:"Authentication required."},{status:401});

    const body=await request.json();
    if(!body.name || !body.category_id)return Response.json({error:"Business name and category are required."},{status:400});

    const {data,error}=await supabase.from("businesses").insert({
      owner_id:user.id,name:body.name,description:body.description||null,
      phone:body.phone||null,address:body.address||null,
      category_id:body.category_id,image_url:body.image_url||null,status:"pending"
    }).select().single();

    if(error)return Response.json({error:error.message},{status:400});
    return Response.json({business:data},{status:201});
  }catch(e){return Response.json({error:e.message},{status:500});}
}
