import { createSupabaseServerClient } from "../../../lib/supabase/server";
import ReviewForm from "../../../components/ReviewForm";

export const dynamic = "force-dynamic";

export default async function BusinessDetail({params}) {
  const supabase = await createSupabaseServerClient();
  const {data:business,error} = await supabase
    .from("businesses")
    .select("*,category:categories(name)")
    .eq("id",params.id)
    .single();

  if(error || !business) return <div className="container"><div className="error">Business not found.</div></div>;

  const {data:reviews} = await supabase
    .from("reviews")
    .select("id,rating,comment,created_at,profiles(full_name)")
    .eq("business_id",business.id)
    .order("created_at",{ascending:false});

  return <div className="container">
    {business.image_url ? <img className="business-img" src={business.image_url} alt={business.name}/> : null}
    <h1>{business.name}</h1>
    <p className="pill">{business.category?.name || "Business"}</p>
    <p>{business.description}</p>
    {business.phone && <p>Phone: {business.phone}</p>}
    {business.address && <p>Address: {business.address}</p>}
    <hr/>
    <h2>Reviews</h2>
    <div className="grid">
      {(reviews||[]).map(r=><div className="card" key={r.id}><strong>{r.rating}/5</strong><p>{r.comment}</p><small>{r.profiles?.full_name || "Customer"}</small></div>)}
    </div>
    <ReviewForm businessId={business.id}/>
  </div>;
}
