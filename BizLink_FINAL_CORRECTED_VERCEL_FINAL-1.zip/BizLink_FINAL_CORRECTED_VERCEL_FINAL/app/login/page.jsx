"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createSupabaseBrowserClient } from "../../lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const [next, setNext] = useState("/dashboard");
  const [supabase, setSupabase] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const requested = new URLSearchParams(window.location.search).get("next");
    setNext(requested && requested.startsWith("/") ? requested : "/dashboard");
    setSupabase(createSupabaseBrowserClient());
  }, []);

  async function handleLogin(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      if (!supabase) throw new Error("Authentication is still loading. Please try again.");
      const { data, error: signInError } = await supabase.auth.signInWithPassword({ email, password });
      if (signInError) throw signInError;
      if (!data.user) throw new Error("Unable to verify your account.");

      // Only admin destinations require the admin role. Normal users use /dashboard.
      if (next.startsWith("/admin")) {
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", data.user.id)
          .maybeSingle();
        if (profileError) throw profileError;
        if (profile?.role !== "admin") {
          await supabase.auth.signOut();
          throw new Error("This account does not have administrator access.");
        }
      }

      router.replace(next);
      router.refresh();
    } catch (err) {
      setError(err?.message || "Unable to sign in. Please check your details and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main style={styles.page}>
      <form onSubmit={handleLogin} style={styles.card}>
        <div style={styles.logo}>B</div>
        <h1 style={styles.title}>Welcome back</h1>
        <p style={styles.subtitle}>Sign in to your BizLink account.</p>

        <label htmlFor="email">Email</label>
        <input id="email" type="email" required autoComplete="email" value={email}
          onChange={e => setEmail(e.target.value)} placeholder="you@example.com" style={styles.input} />

        <label htmlFor="password">Password</label>
        <input id="password" type="password" required autoComplete="current-password" value={password}
          onChange={e => setPassword(e.target.value)} placeholder="••••••••" style={styles.input} />

        {error && <div style={styles.error}>{error}</div>}

        <button type="submit" disabled={loading} style={styles.button}>
          {loading ? "Signing in..." : "Sign in"}
        </button>

        <p style={styles.footerText}>
          Don't have an account? <Link href="/signup">Create one</Link>
        </p>
      </form>
    </main>
  );
}

const styles = {
  page:{minHeight:"70vh",display:"grid",placeItems:"center",padding:20,fontFamily:"Arial,sans-serif"},
  card:{width:"100%",maxWidth:420,background:"#fff",padding:32,borderRadius:18,boxShadow:"0 15px 45px rgba(0,0,0,.08)",display:"flex",flexDirection:"column",gap:10},
  logo:{width:52,height:52,borderRadius:14,display:"grid",placeItems:"center",background:"#111827",color:"#fff",fontSize:26,fontWeight:800},
  title:{margin:0,fontSize:30,color:"#111827"},
  subtitle:{margin:"0 0 15px",color:"#667085"},
  input:{width:"100%",boxSizing:"border-box",padding:13,border:"1px solid #d0d5dd",borderRadius:10,fontSize:16},
  button:{marginTop:10,padding:14,border:0,borderRadius:10,background:"#111827",color:"#fff",fontWeight:700,fontSize:16,cursor:"pointer"},
  error:{padding:12,borderRadius:10,background:"#fee4e2",color:"#b42318",fontSize:14},
  footerText:{textAlign:"center",color:"#667085",fontSize:14,marginTop:8}
};
