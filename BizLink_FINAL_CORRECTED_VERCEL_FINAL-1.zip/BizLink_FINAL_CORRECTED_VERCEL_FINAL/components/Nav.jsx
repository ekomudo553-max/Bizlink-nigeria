"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createSupabaseBrowserClient } from "../lib/supabase/client";

export default function Nav() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const supabase = createSupabaseBrowserClient();
    supabase.auth.getUser().then(({ data }) => setUser(data.user || null));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  return (
    <nav className="nav">
      <Link className="brand" href="/">BizLink</Link>
      <div className="navlinks">
        <Link href="/businesses">Businesses</Link>
        <Link href="/categories">Categories</Link>
        <Link href="/pricing">Pricing</Link>
        <Link href="/dashboard">Dashboard</Link>
        {user ? (
          <Link className="btn" href="/dashboard">My account</Link>
        ) : (
          <>
            <Link href="/signup">Sign up</Link>
            <Link className="btn" href="/login">Sign in</Link>
          </>
        )}
      </div>
    </nav>
  );
}
